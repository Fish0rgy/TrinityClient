﻿using HarmonyLib;
using System;
using System.Collections;
using System.Reflection;
using Area51.SDK.Patching.Patches;
using UnityEngine;

namespace Area51.SDK.Patching
{
    class AlienPatch
    {
        public new static HarmonyLib.Harmony Harmony { get; set; }
        public static HarmonyLib.Harmony Instance = new HarmonyLib.Harmony("Area 51");
        public static HarmonyMethod GetLocalPatch(Type type, string methodName)
        {
            return new HarmonyMethod(type.GetMethod(methodName, BindingFlags.Static | BindingFlags.NonPublic));
        }

        public static void InitPatches()
        {
            try
            {
                 LogHandler.Log(LogHandler.Colors.Green, "[Patch] Starting Patches....", false, false);
                _Spoofers.InitSpoofs();
                _Udon.InitUdon();
                _OnEvent.InitOnEvent();
                _AvatarAssetBundleLoad.InitAOnAssetBundleLoad();
                _Logging.InitLogging();
                _OnUInit.OnUIInit();
              
            } catch (Exception ERR) { LogHandler.Log(LogHandler.Colors.Green, ERR.Message, false, false); }
        }

        public static IEnumerator StartPatches()
        {
           
            yield return new WaitForSecondsRealtime(0.1f);
        }
    }
}
