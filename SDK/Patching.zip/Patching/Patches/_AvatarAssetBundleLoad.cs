﻿using HarmonyLib;
using System.Reflection;
using UnityEngine;
using VRC.Core;

namespace Area51.SDK.Patching.Patches
{
    public static class _AvatarAssetBundleLoad 
    {
        public static void InitAOnAssetBundleLoad()
        {
            try
            {
                AlienPatch.Instance.Patch(typeof(VRC.Core.AssetManagement).GetMethod("Method_Public_Static_Object_Object_Boolean_Boolean_Boolean_0"), new HarmonyMethod(AccessTools.Method(typeof(_AvatarAssetBundleLoad), nameof(OnAvatarAssetBundleLoad))));

                SDK.LogHandler.Log(SDK.LogHandler.Colors.Green, "[Patch] AssetBundle", false, false);
            }
            catch
            {
                SDK.LogHandler.Log(SDK.LogHandler.Colors.Red, "[Patch] [Error] AssetBundle", false, false);
            }
        }



        [Obfuscation(Exclude = true)]
        private static bool OnAvatarAssetBundleLoad(ref UnityEngine.Object __0)
        {
            GameObject gameObject = __0.TryCast<GameObject>();
            if (gameObject == null)
            {
                return true;
            }
            if (!gameObject.name.ToLower().Contains("avatar"))
            {
                return true;
            }
            string avatarId = gameObject.GetComponent<PipelineManager>().blueprintId;
            for (int i = 0; i < Main.Instance.OnAssetBundleLoadEventArray.Length; i++)
                if (!Main.Instance.OnAssetBundleLoadEventArray[i].OnAvatarAssetBundleLoad(gameObject, avatarId))
                    return false;

            return true;
        }

    }
}
